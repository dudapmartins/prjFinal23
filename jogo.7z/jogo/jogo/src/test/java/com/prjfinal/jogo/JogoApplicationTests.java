package com.prjfinal.jogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
